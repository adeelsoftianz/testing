<?php //error_reporting(0);
    header("Connection: Keep-alive");
    //include('minify.php');
    include('includes/class.php');
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Softianz - Technology Solutions</title>
    <meta name="author" content="Themeholy">
    <meta name="description" content="Webteck - Technology & IT Solutions HTML Template">
    <meta name="keywords" content="Webteck - Technology & IT Solutions HTML Template">
    <meta name="robots" content="INDEX,FOLLOW">

    <?php include("includes/header-settings.php"); ?>

    <?php include("includes/css-files.php"); ?>
    
</head>

<body class="gr-bg5">

    <div class="cursor"></div>
    <div class="cursor2"></div>

    <?php include("includes/header.php"); ?>

    <div class="th-hero-wrapper hero-4" id="hero">
        <div class="body-particle" id="body-particle"></div>
        <div class="hero-img tilt-active">
            <img src="assets/img/hero/hero_img_4_1.png" alt="Hero Image">
        </div>
        <div class="container">
            <div class="hero-style4">
                <div class="ripple-shape">
                    <span class="ripple-1"></span><span class="ripple-2"></span><span class="ripple-3"></span><span class="ripple-4"></span><span class="ripple-5"></span><span class="ripple-6"></span>
                </div>
                <span class="hero-subtitle">SMM Services</span>
                <h1 class="hero-title">Social Media Marketing</h1>
                <h4>Transform Your Brand's Presence with Softianz</h4>
                <p class="hero-text">
                    Social Media Marketing (SMM) plays an important role in today's digital age, offering businesses a multitude of benefits. By harnessing the power of social media platforms, businesses can significantly enhance their online presence, connect with their target audience on a deeper level, and build lasting relationships. Get ready to stand out in the digital crowd with Softianz's dynamic social media marketing strategies. We don't just create content, we craft experiences that engage, inspire, and drive action.
                </p>
                <div class="btn-group">
                    <a href="#" class="th-btn style4 style-radius" data-bs-toggle="modal" data-bs-target="#modalContactForm">
                        Get Started<i class="fa-regular fa-arrow-right ms-2"></i>
                    </a>
                    <!--<a href="tel:+2586232325" class="th-btn style4 style-radius">Call us: +258 6232 3258</a>-->
                    
                </div>
            </div>
        </div>
        <div class="triangle-1"></div>
        <div class="triangle-2"></div>
        <div class="hero-shape2">
            <img src="assets/img/hero/hero_shape_2_2.png" alt="shape">
        </div>
        <div class="hero-shape3">
            <img src="assets/img/hero/hero_shape_2_3.png" alt="shape">
        </div>
    </div>



    <!--==============================
            Portfolio
    ==============================-->
    <section class="overflow-hidden bg-white space">
        <div class="container th-container5">
            <div class="row">
                <div class="col-xl-4">
                    <div class="title-area mb-50 text-center text-md-start">
                        <span class="sub-title">
                            <div class="icon-masking me-2">
                                <span class="mask-icon" data-mask-src="assets/img/theme-img/title_shape_1.svg"></span>
                                <img src="assets/img/theme-img/title_shape_1.svg" alt="shape">
                            </div>
                            SMM Portfolio
                        </span>
                        <h2 class="sec-title">Boost Your Brand's Visibility and Authority</h2>
                        <p class="section-text">
                            Social Media provides valuable insights and analytics that enable businesses to refine their strategies and optimize their campaigns for maximum impact. SMM facilitates increased brand awareness, fosters customer engagement, and drives traffic to websites or online stores.
                        </p>
                        <p class="section-text">
                            Let's increase your brand awareness, drive traffic, and boost sale by connecting Softianz as your Social Media Marketing strategist.
                        </p>
                    </div>
                    <div class="project-btn">
                        <a href="#" class="th-btn style-border style-radius" data-bs-toggle="modal" data-bs-target="#modalContactForm">
                            Get Connected
                        </a>
                    </div>
                </div>
                <div class="col-xl-8">
                    <div class="slider-area project-slider4">
                        <div class="swiper th-slider has-shadow" id="projectSlider1" data-slider-options='{"breakpoints":{"0":{"slidesPerView":1},"576":{"slidesPerView":"1"},"768":{"slidesPerView":"2"},"992":{"slidesPerView":"2"},"1200":{"slidesPerView":"2"}}}'>
                            <div class="swiper-wrapper">
                                <!-- Single Item -->
                                <div class="swiper-slide">
                                    <div class="project-box4">
                                        <div class="project-img">
                                            <img src="https://web.archive.org/web/20210417173637im_/https://www.digitrillion.com/images/logo/kingmonk-digitrillion.jpg" alt="project">
                                        </div>
                                        <div class="project-content">
                                            <div class="media-body">
                                                <h3 class="box-title"><a href="project-details.html">Technology Growth</a></h3>
                                                <div class="project-tags">
                                                    <a href="project-details.html">Marketing</a>
                                                    <a href="project-details.html">Service</a>
                                                    <a href="project-details.html">Solution</a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <!-- Single Item -->
                                <div class="swiper-slide">
                                    <div class="project-box4">
                                        <div class="project-img">
                                            <img src="https://web.archive.org/web/20210417173637im_/https://www.digitrillion.com/images/logo/braintech-digitrillion.jpg" alt="project">
                                        </div>
                                        <div class="project-content">
                                            <div class="media-body">
                                                <h3 class="box-title"><a href="project-details.html">IT Consultency</a></h3>
                                                <div class="project-tags">
                                                    <a href="project-details.html">Marketing</a>
                                                    <a href="project-details.html">Service</a>
                                                    <a href="project-details.html">Solution</a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <!-- Single Item -->
                                <div class="swiper-slide">
                                    <div class="project-box4">
                                        <div class="project-img">
                                            <img src="https://web.archive.org/web/20210417173637im_/https://www.digitrillion.com/images/logo/deepdiet-digitrillion.jpg" alt="project">
                                        </div>
                                        <div class="project-content">
                                            <div class="media-body">
                                                <h3 class="box-title"><a href="project-details.html">Technology Growth</a></h3>
                                                <div class="project-tags">
                                                    <a href="project-details.html">Marketing</a>
                                                    <a href="project-details.html">Service</a>
                                                    <a href="project-details.html">Solution</a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>

                                <!-- Single Item -->
                                <div class="swiper-slide">
                                    <div class="project-box4">
                                        <div class="project-img">
                                            <img src="https://web.archive.org/web/20210417173637im_/https://www.digitrillion.com/images/logo/pineapple-digitrillion.jpg" alt="project">
                                        </div>
                                        <div class="project-content">
                                            <div class="media-body">
                                                <h3 class="box-title"><a href="project-details.html">IT Consultency</a></h3>
                                                <div class="project-tags">
                                                    <a href="project-details.html">Marketing</a>
                                                    <a href="project-details.html">Service</a>
                                                    <a href="project-details.html">Solution</a>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>


    <!--==============================
            Choose Us Area  
    ==============================-->
    <div class="why-sec-v2" data-bg-src="assets/img/bg/why_bg_2.jpg">
        <div class="container space">
            <div class="row align-items-center flex-row-reverse">
                <div class="col-xl-6 mb-30 mb-xl-0">
                    <div class="img-box5">
                        <img class="tilt-active" src="assets/img/normal/why_2_1.png" alt="Why">
                        <div class="year-counter">
                            <h3 class="year-counter_number"><span class="counter-number">50</span>+</h3>
                            <p class="year-counter_text">Clients Active</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-6">
                    <div class="title-area mb-35">
                        
                        <span class="sub-title">
                            <div class="icon-masking me-2">
                                <span class="mask-icon" data-mask-src="assets/img/theme-img/title_shape_2.svg"></span>
                                <img src="assets/img/theme-img/title_shape_2.svg" alt="shape">
                            </div>WHY CHOOSE US
                        </span>
                        <h2 class="sec-title">Empower Your <span class="text-theme">Brand's Social Media</span> Journey with Softianz</h2>
                    </div>
                    <p class="mt-n2 mb-30 section-text">
                       Softianz brings a dynamic approach to Social Media Marketing (SMM) that goes beyond the basics. We understand that every brand is unique, which is why our strategies are tailor-made to resonate with your brand's identity and goals. By blending creativity, data-driven insights, and industry expertise, we create engaging campaigns that not only boost the brand awareness and engagement but also drive tangible results like increased conversions and ROI. Join Softianz and unlock the full potential of your brand's social media journey.
                    </p>
                    <?php /*
                    <div class="about-feature-wrap">
                        <div class="about-feature">
                            <div class="about-feature_icon">
                                <img src="assets/img/icon/about_feature_1_1.svg" alt="Icon">
                            </div>
                            <div class="media-body">
                                <h3 class="about-feature_title">Certified Company</h3>
                                <p class="about-feature_text">Best Provide Skills Services</p>
                            </div>
                        </div>
                        <div class="about-feature">
                            <div class="about-feature_icon">
                                <img src="assets/img/icon/about_feature_1_2.svg" alt="Icon">
                            </div>
                            <div class="media-body">
                                <h3 class="about-feature_title">Expert Team</h3>
                                <p class="about-feature_text">Highly Skilled Team</p>
                            </div>
                        </div>
                    </div>*/ ?>
                    <div class="feature-circle-wrap">
                        <div class="feature-circle">
                            <div class="progressbar" data-path-color="#684DF4">
                                <div class="circle" data-percent="90">
                                    <div class="circle-num">50</div>
                                </div>
                            </div>
                            <div class="media-body">
                                <h3 class="feature-circle_title">Satisfied Clients</h3>
                                <p class="feature-circle_text">Efficiently transition top-line ideas before market.</p>
                            </div>
                        </div>
                        <div class="feature-circle">
                            <div class="progressbar" data-path-color="#684DF4">
                                <div class="circle" data-percent="95">
                                    <div class="circle-num"></div>
                                </div>
                            </div>
                            <div class="media-body">
                                <h3 class="feature-circle_title">Design Quality</h3>
                                <p class="feature-circle_text">Efficiently transition top-line ideas before market.</p>
                            </div>
                        </div>
                    </div>

                   
                </div>
            </div>
        </div>
    </div>

    <?php include("includes/numbers-counter.php"); ?>



    <!--==============================
            Price Area  
    ==============================-->
    <section class="space">
        <div class="container th-container5">
            <div class="title-area text-center">
                <span class="sub-title">
                    <div class="icon-masking me-2">
                        <span class="mask-icon" data-mask-src="assets/img/theme-img/title_shape_1.svg"></span>
                        <img src="assets/img/theme-img/title_shape_1.svg" alt="shape">
                    </div>
                    Pricing Plans
                </span>
                <h2 class="sec-title">Effective Pricing Plans</h2>
                <p class="section-text">
                    Is your brand ready to stand out? Check out our social media marketing pricings and choose the package that suits you best! With a range of prices, you can find the perfect fit for any budget. Unleash your potential, contact us now and see how we can help!
                </p>
            </div>
            <div class="row gy-4 justify-content-center">

                <div class="col-xl-4 col-md-6">
                    <div class="price-box th-ani ">
                        <h3 class="box-title">Normal Plan</h3>
                        <span class="offer-tag"></span>
                        <h4 class="price-box_price"><span class="currency">$</span>19.00</h4>
                        <h6 class="price-box_text">Get Popular Plan From Us</h6>
                        <div class="price-box_content">
                            <div class="available-list">
                                <ul>
                                    <li>Ad Management</li>
                                    <li>Multi-Language Content</li>
                                    <li>Conversational Bots</li>
                                </ul>
                            </div>
                            <a href="contact.html" class="th-btn btn-fw style-radius" data-bs-toggle="modal" data-bs-target="#modalContactForm">
                                Choose Plan
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6">
                    <div class="price-box th-ani active">
                        <h3 class="box-title">Standard Plan</h3>
                        <span class="offer-tag"><span class="tag">Featured</span></span>
                        <h4 class="price-box_price"><span class="currency">$</span>29.00</h4>
                        <h6 class="price-box_text">Get Popular Plan From Us</h6>
                        <div class="price-box_content">
                            <div class="available-list">
                                <ul>
                                    <li>Ad Management</li>
                                    <li>Live Chat</li>
                                    <li>Multi-Language Content</li>
                                    <li> Conversational Bots</li>
                                    <li> Programmable Chatbots</li>
                                </ul>
                            </div>
                            <a href="contact.html" class="th-btn btn-fw style-radius" data-bs-toggle="modal" data-bs-target="#modalContactForm">
                                Choose Plan
                            </a>
                        </div>
                    </div>
                </div>

                <div class="col-xl-4 col-md-6">
                    <div class="price-box th-ani ">
                        <h3 class="box-title">Ultimate Plan</h3>
                        <span class="offer-tag"></span>
                        <h4 class="price-box_price"><span class="currency">$</span>39.00</h4>
                        <h6 class="price-box_text">Get Popular Plan From Us</h6>
                        <div class="price-box_content">
                            <div class="available-list">
                                <ul>
                                    <li>Ad Management</li>
                                    <li>Multi-Language Content</li>
                                    <li>Conversational Bots</li>
                                </ul>
                            </div>
                            <a href="contact.html" class="th-btn btn-fw style-radius" data-bs-toggle="modal" data-bs-target="#modalContactForm">
                                Choose Plan
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
    

    <?php include("includes/contact-cta-section.php"); ?>

    <?php include("includes/testimonial-section.php"); ?>

    <?php include("includes/clients-logo-slider.php"); ?>

    <?php include("includes/footer.php"); ?>
    
    <?php include("includes/cta-modal-popup.php"); ?>

    <?php include("includes/js-files.php"); ?>

</body>

</html>