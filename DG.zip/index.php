<?php //error_reporting(0);
    header("Connection: Keep-alive");
    //include('minify.php');
    include('includes/class.php');
?>
<!doctype html>
<html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Softianz - Technology Solutions</title>
    <meta name="author" content="Themeholy">
    <meta name="description" content="Webteck - Technology & IT Solutions HTML Template">
    <meta name="keywords" content="Webteck - Technology & IT Solutions HTML Template">
    <meta name="robots" content="INDEX,FOLLOW">

    <?php include("includes/header-settings.php"); ?>

    <?php include("includes/css-files.php"); ?>
    
</head>

<body class="gr-bg5">

    <div class="cursor"></div>
    <div class="cursor2"></div>

    <?php include("includes/header.php"); ?>

    <?php include("includes/hero-section.php"); ?>

    <?php include("includes/about-section.php"); ?>

    <?php include("includes/numbers-counter.php"); ?>    

    <?php include("includes/why-us-section.php"); ?>    

    <?php include("includes/parallax-cta-section.php"); ?>

    <?php include("includes/services-section.php"); ?>    

    <?php include("includes/contact-cta-section.php"); ?>

    <?php include("includes/testimonial-section.php"); ?>

    <?php include("includes/clients-logo-slider.php"); ?>

    <?php include("includes/footer.php"); ?>
    
    <?php include("includes/cta-modal-popup.php"); ?>

    <?php include("includes/js-files.php"); ?>

</body>

</html>