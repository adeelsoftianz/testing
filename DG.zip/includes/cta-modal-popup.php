    <div class="modal fade" id="modalContactForm" tabindex="-1" aria-labelledby="myModalLabel" aria-hidden="true">
       
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="exampleModalLabel">Please fill in the information below</h4>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"><b>X</b></button>
                </div>
                <div class="modal-body">
                    <div class="appointment-area-wrapp">
                        <form action="mail.php" method="POST" class="appointment-form3 input-smoke ajax-contact">
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="name">Your name*</label>
                                    <input type="text" class="form-control" name="name" id="name" placeholder="">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name">Email address*</label>
                                    <input type="email" class="form-control" name="email" id="email" placeholder="">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name">Phone number*</label>
                                    <input type="tel" class="form-control" name="number" id="number" placeholder="">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="name">Company website*</label>
                                    <input type="text" class="form-control" name="text" id="text" placeholder="">
                                </div>
                                <div class="form-group col-12">
                                    <label for="name">Company / Organization about*</label>
                                    <input type="text" class="form-control" name="text" id="text2" placeholder="">
                                </div>
                                <div class="form-group col-12">
                                    <label for="name">Describe your message*</label>
                                    <textarea name="message" id="message" cols="30" rows="3" class="form-control" placeholder=""></textarea>
                                </div>
                                <div class="form-btn col-12">
                                    <button type="button" class="th-btn btn-fw">Submit Now</button>
                                </div>
                            </div>
                            <p class="form-messages mb-0 mt-3"></p>
                        </form>
                    </div>
                </div>
                <!--<div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary">Save changes</button>
                </div>-->
            </div>
        </div>
           
    </div>