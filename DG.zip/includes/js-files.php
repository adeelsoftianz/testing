    <?php /*
    ==============================
            All Js File
    ==============================
    */ ?>
    <!-- Jquery -->
    <script src="<?php echo JS; ?>vendor/jquery-3.7.1.min.js"></script>
    <!-- Swiper Slider -->
    <script src="<?php echo JS; ?>swiper-bundle.min.js"></script>
    <!-- Bootstrap -->
    <script src="<?php echo JS; ?>bootstrap.min.js"></script>
    <!-- Magnific Popup -->
    <script src="<?php echo JS; ?>jquery.magnific-popup.min.js"></script>
    <!-- Counter Up -->
    <script src="<?php echo JS; ?>jquery.counterup.min.js"></script>
    <!-- Circle Progress -->
    <script src="<?php echo JS; ?>circle-progress.js"></script>
    <!-- Range Slider -->
    <script src="<?php echo JS; ?>jquery-ui.min.js"></script>
    <!-- Isotope Filter -->
    <script src="<?php echo JS; ?>imagesloaded.pkgd.min.js"></script>
    <script src="<?php echo JS; ?>isotope.pkgd.min.js"></script>
    <!-- Tilt JS -->
    <script src="<?php echo JS; ?>tilt.jquery.min.js"></script>

    <!-- gsap -->
    <script src="<?php echo JS; ?>gsap.min.js"></script>
    <!-- ScrollTrigger -->
    <script src="<?php echo JS; ?>ScrollTrigger.min.js"></script>
    <script src="<?php echo JS; ?>smooth-scroll.js"></script>

    <!-- Particles JS -->
    <script src="<?php echo JS; ?>particles.min.js"></script>

    <script src="<?php echo JS; ?>particles-config.js"></script>
    <!-- Main Js File -->
    <script src="<?php echo JS; ?>main.js"></script>