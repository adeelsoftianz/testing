<?php //session_start();
	require_once('includes/constant.php');
	//require_once('includes/connection.php');

	$page_name 	= 	$_SERVER['PHP_SELF'];	
?>